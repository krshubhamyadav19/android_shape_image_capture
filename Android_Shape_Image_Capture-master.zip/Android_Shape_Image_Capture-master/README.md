# Android_Shape_Image_Capture


  ## Requirements
  - Nedd  attached screenshot camera view
 - Open Camera using surface/texture View
 - show given shape area in clear view
 - Show rest of the area with alpha
 - Have a give shape area on that view, when the pic is clicked only shape area should be captured
 - user can chose shape according to need

 ## Refrence
 ![Alt text](/qr_code_scanner.webp?raw=true "ScreenShot")


 ## How its work
 
 
 -----------------------------------------------------------------------
 ### Docuemetation
 -----------------------------------------------------------------------
 
 
 
 
 
 #### Refrences

